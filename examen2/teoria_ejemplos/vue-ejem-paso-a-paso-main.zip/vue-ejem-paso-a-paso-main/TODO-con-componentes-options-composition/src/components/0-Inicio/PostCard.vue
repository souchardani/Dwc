<template>
    <div class="post-card">
        <h3>TITULO...</h3>
        <p>
         Commodo et aute ut irure ea enim sint et commodo velit cillum elit. In incididunt elit cupidatat cillum elit id consequat eiusmod sunt aliqua. Sint laborum sint enim sunt amet veniam non sint consectetur adipisicing fugiat id excepteur occaecat.
        </p>
        <PostButton />
    </div>
    
</template>   

<script setup >
    import PostButton from './PostButton.vue'

</script>

<style>
.post-card{
    border-radius: 15px;
    padding: 10px;
    margin: 5px;
    border: 1px solid #ccc;
}
</style>