<template>
    <button class="post-btn">ACCEDER</button>
</template>

<script setup>
</script>

<style scoped>
.post-btn{
    padding: 15px;
    background-color: blueviolet;
    color: white;
    border: 0;
    outline: 0;
}
.post-btn:hover{
    background-color: white;
    color: blueviolet;
}
</style>