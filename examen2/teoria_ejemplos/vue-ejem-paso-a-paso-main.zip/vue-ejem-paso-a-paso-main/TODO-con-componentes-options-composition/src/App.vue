<template>
  <h1>Diferentes Componentes</h1>
  <!-- <PostContainer></PostContainer> -->
  <!-- <CounterOption /> -->
  <!-- <CounterComposition></CounterComposition> -->
  <!-- <ListasOption></ListasOption> -->
  <!-- <ListasComposition></ListasComposition> -->
  <!-- <EventosOption></EventosOption> -->
  <!-- <EventosComposition></EventosComposition> -->
  <!-- <PropiedadesComputadasOption></PropiedadesComputadasOption> -->
  <!-- <PropiedadesComputadasComposition></PropiedadesComputadasComposition> -->
  <!-- <DataBindClassesOption></DataBindClassesOption> -->
  <!-- <DataBindClassesComposition></DataBindClassesComposition> -->
  <!-- <AxiosOption></AxiosOption> -->
  <!-- <AxiosComposition></AxiosComposition> -->
  <!-- <AxiosFilterOption></AxiosFilterOption> -->
  <!-- <AxiosFilterComposition></AxiosFilterComposition> -->
  <!-- <PostListComponent/> -->
  <!-- <PostListOption/> -->
  <!-- <PostListHijoPadreComponent/> -->
  <!-- <PostListHijoPadreOption/> -->
  <!-- <DirectivasPersonalizadasComposition/> -->
  <DirectivasPersonalizadasOption />
</template>


<script setup>

//0-Inicio
  // import PostContainer from './components/0-Inicio/PostContainer.vue'
  // import CounterOption from './components/0-Inicio/CounterOption.vue';
  // import CounterComposition from './components/0-Inicio/CounterComposition.vue';
//3-Renderizado de Listas
  // import ListasOption from './components/3-renderizado-listas/3-ListasOption.vue'
 // import ListasComposition from './components/3-renderizado-listas/ListasComposition.vue';
//5-Eventos
  // import EventosOption from './components/4-Eventos/EventosOption.vue'
  // import EventosComposition from './components/4-Eventos/EventosComposition.vue';
//6-Propiedades Computadas
  // import PropiedadesComputadasOption from './components/6-Propiedades-Computadas/PropiedadesComputadasOption.vue';
  // import PropiedadesComputadasComposition from './components/6-Propiedades-Computadas/PropiedadesComputadasComposition.vue';
//9-data-binding-atributos-clases
  // import DataBindClassesOption from './components/9-data-binding-atributos-clases/DataBindClassesOption.vue';
  // import DataBindClassesComposition from './components/9-data-binding-atributos-clases/DataBindClassesComposition.vue';
//12-Axios
    //import AxiosOption from './components/12-Axios/AxiosOption.vue';
  // import AxiosComposition from './components/12-Axios/AxiosComposition.vue';
//12.1-Axios-Filter
  // import AxiosFilterOption from './components/12.1-Axios-Filter/AxiosFilterOption.vue';
  // import AxiosFilterComposition from './components/12.1-Axios-Filter/AxiosFilterComposition.vue';
//13-Comunicacion entre Componentes
  //13.1-Comunicacion Padre-Hijo => Props
  // import PostListComponent from './components/13-ComunicacionEntreComponentes/13.1-Comunicacion Padre-Hijo/PostListComponent.vue'
  // import PostListOption from './components/13-ComunicacionEntreComponentes/13.1-Comunicacion Padre-Hijo/PostListOption.vue'
  //13.2-Comuicacion Hijo-Padre => emit events
  // import PostListHijoPadreComponent from './components/13-ComunicacionEntreComponentes/13.2-Comunicacion Hijo-padre/PostList-HijoPadreComponent.vue'
  // import PostListHijoPadreOption from './components/13-ComunicacionEntreComponentes/13.2-Comunicacion Hijo-padre/PostList-HijoPadreOption.vue'; 
  //2- Directivas Personalizadas 
  // import DirectivasPersonalizadasComposition from './components/2-Directivas-Personalizadas/DirectivasPersonalizadasComposition.vue';
  import DirectivasPersonalizadasOption from './components/2-Directivas-Personalizadas/DirectivasPersonalizadasOption.vue';
</script>

<style scoped>
h1{
  color: red;
}
</style>
