<template>
    <h1>Sección Contactos</h1>
</template>