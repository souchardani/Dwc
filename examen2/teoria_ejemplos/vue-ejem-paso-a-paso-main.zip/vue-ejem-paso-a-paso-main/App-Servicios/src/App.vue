<template>
  <!-- <PostListadoComposition/> -->
  <PostListadoOption/>
</template>


<script setup>

import PostListadoComposition from './components/PostListadoComposition.vue';
import PostListadoOption from './components/PostListadoOption.vue';


</script>



<style scoped>

</style>
