<template>
  <div class="about">
    <h1>Acerca de</h1>
  </div>
</template>