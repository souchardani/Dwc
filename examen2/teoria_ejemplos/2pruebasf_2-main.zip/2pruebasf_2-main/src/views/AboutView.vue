<template>
  <div class="about">
    <h1>This is an about page</h1>
  </div>
</template>

<script>
  import axios from 'axios';
  export default {
      
      data(){
        return{
          
        }
      },
      mounted() {
      },
    methods:{
      
      }
    }
</script>