window.onload = function () {
  obtenerProductos();
};

// //evento del click del boton de agregar factura
// document
//   .getElementById("anadirFactura")
//   .addEventListener("click", anadirFactura);

document
  .getElementById("anadirFactura")
  .addEventListener("click", anadirFactura);

document.addEventListener("keyup", function (event) {
  event.preventDefault();
  if (event.key === "Enter") {
    anadirFactura();
  }
});

function obtenerProductos() {
  fetch("php/productos.php", {
    method: "POST",
  })
    .then((resp) => resp.json())
    .then((data_resp) => {
      // la data_resp nos llega en formato JSON
      cargarProductosLista(data_resp);
    });
}

function cargarProductosLista(datos) {
  let trtabla = document.getElementById("tbodyproductos");
  for (const dato of datos) {
    let tr = document.createElement("tr");
    string = `
        <td>${dato.descripcion}</td>
        <td>${dato.codigo}</td>
        <td>${dato.precio}€</td>
    `;
    tr.innerHTML = string;
    trtabla.appendChild(tr);
  }
}

function anadirFactura() {
  //obtenemos el producto del input
  let prod = document.querySelector("#txtProducto");
  let cant = document.querySelector("#txtCantidad");
  if (prod.value) {
    //traemos los datos de ese producto del php
    fetch("php/productoFactura.php", {
      method: "POST",
      body: prod.value,
    })
      .then((response) => response.json())
      .then((resultado) => {
        console.log("Resultado del servidor:", resultado);
        agregarFilaFactura(resultado, cant.value);
      })
      .catch((error) => console.error("Fetch error:", error));
    // reiniciamos las cajas de texto
    prod.value = "";
    cant.value = "";
  } else {
    alert("El campo de texto no puede estar vacio");
  }
}

function agregarFilaFactura(producto, cantidad) {
  // obtenemos la tabla
  let tabla = document.getElementById("tablaFactura");

  // creamos una nueva fila
  let fila = document.createElement("tr");

  // agregamos las celdas con la información del producto
  fila.innerHTML = `
    <td>${producto[0].codigo}</td>
    <td>${cantidad}</td>
    <td>${producto[0].descripcion}</td>
    <td class="text-center font-medium text-green-500">${
      producto[0].precio
    }€</td>
    <td class="text-lg text-center">${calcularPrecioTotal(
      producto[0].precio,
      cantidad
    )}€</td>
  `;

  // agregamos la fila a la tabla
  tabla.appendChild(fila);

  // actualizamos los totales
  actualizarTotales();
}

function calcularPrecioTotal(precioUnitario, cantidad) {
  return precioUnitario * cantidad;
}

function actualizarTotales() {
  // Implementa la lógica para actualizar los totales en la factura
  // Puedes recorrer las filas de la tabla y sumar los totales
}
