function pintarColor(nuevoElemento, color) {
    switch (color) {
        case 'amarillo':
            nuevoElemento.classList.add('envases');
            break;
        case 'verde':
            nuevoElemento.classList.add('vidrio');
            break;
        case 'azul':
            nuevoElemento.classList.add('papel');
            break;
        case 'marron':
            nuevoElemento.classList.add('organico');
            break;
        case 'naranja':
            nuevoElemento.classList.add('aceite');
            break;
        default:
            break;
        }
    }