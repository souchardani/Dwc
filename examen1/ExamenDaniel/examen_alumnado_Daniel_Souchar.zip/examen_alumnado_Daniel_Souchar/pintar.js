//para optimizar la funcion, como ya el elemento tiene el color, no hace falta pasarselo, asi que haria lo siguiente:
//pasamos el nuevo elemento p, y el objeto descarga que teniamos para acceder al color
function pintarColor(nuevoElemento, objetoDescarga) {
  //creo un array para asociar el nombre de valor con la clase
  let clases = {
    amarillo: "envases",
    verde: "vidrio",
    azul: "papel",
    marron: "organico",
    naranja: "aceite",
  };
  //ahora, para el elemento:
  let clase = clases[objetoDescarga.color];
  nuevoElemento.classList.add(`${clase}`);
}

// function pintarColor(nuevoElemento, color) {
//   console.log(nuevoElemento);
//   switch (color) {
//     case "amarillo":
//       nuevoElemento.classList.add("envases");
//       break;
//     case "verde":
//       nuevoElemento.classList.add("vidrio");
//       break;
//     case "azul":
//       nuevoElemento.classList.add("papel");
//       break;
//     case "marron":
//       nuevoElemento.classList.add("organico");
//       break;
//     case "naranja":
//       nuevoElemento.classList.add("aceite");
//       break;
//     default:
//       break;
//   }
// }
