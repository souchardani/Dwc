//definimos las variables de manera global
let nombre;
let kg;
let residuo;
let formulario;
let arrayDescargas = [];

document.addEventListener("DOMContentLoaded", inicializar);

function inicializar() {
  //añadimos los event listeners
  formulario = document.getElementById("contenedor-form");
  formulario.addEventListener("submit", (event) => {
    //usamos esta funcion para no enviar el formulario por defecto cuando pulsamos enviar
    event.preventDefault();
    //ahora llamamos a la funcion validar para comprobar campos
    validar();
  });
}

//funcion para obtener los valores actuales de las cajas de texto
function obtenerValores() {
  nombre = document.getElementById("nombre");
  kg = document.getElementById("kg");
  let SelectEnvase = document.getElementById("residuo");
  residuo = SelectEnvase.options[SelectEnvase.selectedIndex]; //de esto necesito el value
}

function crearDescarga() {
  //creamos un nuevo objeto de tipo descarga
  let descarga = new Descarga(
    residuo.value,
    residuo.text,
    kg.value,
    nombre.value
  );

  //añadimos al array de descargas la nueva descarga
  addArray(arrayDescargas, descarga);
  //como al añadir al array ya se llama al metodo mostrar array, no hace falta volver a añadirlo
  //ya hemos creado la descarga, ahora mostramos el texto en el div descargas
  mostrarTexto(descarga);
  //al añadir la descarga, tambien actualizamos los kg
  actualizarKg(descarga);
}

function mostrarTexto(descarga) {
  //con la descarga que creamos, añadimos al dom el elemento nuevo p
  let texto = document.createElement("p");
  let fecha = new Date();
  fecha = `${fecha.getDate()}/${fecha.getMonth() + 1}/${fecha.getFullYear()}`;
  let innerTexto = `${descarga.nombre} ha descargado ${descarga.kg} kg de residuo ${descarga.residuo} en el contenedor ${descarga.color} el dia ${fecha}`;
  texto.textContent = innerTexto;

  //obtenemos el elemento del dom
  let parrafo = document.getElementById("descargas");
  //y añadimos el parrafo creado
  parrafo.appendChild(texto);
  //le damos el color al texto
  pintarColor(texto, descarga);
}

function actualizarKg(descarga) {
  //para hacerlo funcional, obtenemos el campo dinamicamente desde el objeto descarga
  let residuo = descarga.residuo.toLowerCase();
  let valorActual = parseInt(document.getElementById(residuo).value);
  let valorNuevo = valorActual + parseInt(descarga.kg);
  //añadimos el valor nuevo al formulario
  document.getElementById(residuo).value = valorNuevo;
}
