//metodo para añadir elementos al array
function addArray(array, elemento) {
  //añadimos el elemento al inicio del array con unshift
  array.unshift(elemento);
  //llamamos al metodo mostarArray
  mostrarArray(array);
}

//metodo para mostrar
function mostrarArray(array) {
  //para cada elemento del array, mostrarmos sus datos con la funcion mostrar() de descarga.js
  array.forEach((elemento) => {
    console.log(elemento.mostrar());
  });
}
