// clases y objetos
//creamos la clase
class Descarga {
  //definimos el constructor de la clase
  constructor(color, residuo, kg, nombre) {
    this._color = color;
    this._residuo = residuo;
    this._kg = kg;
    this._nombre = nombre;
  }

  //definimos getters y setters
  get color() {
    return this._color;
  }

  set color(color) {
    this._color = color;
  }

  get residuo() {
    return this._residuo;
  }

  set residuo(residuo) {
    this._residuo = residuo;
  }

  get kg() {
    return this._kg;
  }

  set kg(kg) {
    this._kg = kg;
  }

  get nombre() {
    return this._nombre;
  }

  set nombre(nombre) {
    this._nombre = nombre;
  }

  //creamos el metodo mostrar
  mostrar() {
    return `${this.nombre} ha depositado ${this.kg} kg del residuo ${this.residuo} en el contenedor ${this.color}`;
  }
}
