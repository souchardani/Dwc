function validar() {
  //inicializamos todos los valores actuales
  obtenerValores();
  let msgError = [];
  let numero = validarNumero();
  if (!numero) {
    //añadimos el mensaje de error a un array para mostrarlo en el alert
    msgError.push("El numero debe ser positivo, Entre 0 y 100");
  }
  let nombre = validarNombre();
  if (!nombre) {
    msgError.push(
      "El nombre debe tener por letras mayúsculas o minúsculas y espacios, como mínimo 3 letras y como máximo 20"
    );
  }
  //si hay algun mensaje de error, es que no se ha hecho la validacion
  if (msgError.length > 0) {
    let mensajeCompleto = "";
    msgError.forEach((mensaje) => {
      mensajeCompleto += mensaje + "\n";
    });
    alert(mensajeCompleto);
  } else {
    //si no hay mensaje de error creamos la descarga
    crearDescarga();
  }
}

function validarNumero() {
  let num = parseInt(kg.value);
  return num > 0 && num <= 100;
}

function validarNombre() {
  let patron = /^[a-zA-ZáéíóúñÁÉÍÓÚÑs\s]+$/g; //letras mayusculas minusculas
  let patron2 = /\w{3,20}/g; //entre 3 y 20 caracteres
  if (patron.test(nombre.value)) {
    return patron2.test(nombre.value);
  } else {
    return false;
  }
}
